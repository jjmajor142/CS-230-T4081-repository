/*Joshua Major
 * CS-230-T4081
 * 02/20/2021
 * Project1
 */
package com.gamingroom;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * A singleton service for the game engine
 * 
 * @author coce@snhu.edu
 */
public class GameService {

	/**
	 * A list of the active games
	 */
	private static List<Game> games = new ArrayList<Game>();

	/*
	 * Holds the next game, team, and player identifiers
	 */
	private static long nextGameId = 1;
	private static long nextTeamId = 1;
	private static long nextPlayerId = 1;

	// This line creates a single instance of the GameService class
	//and will not allow another one to be created. Because itis 
	//private it can not be called from outside of the class. 
	private static GameService instance = new GameService();
	
	
	private GameService() {}
	
	//returns the singleton instance of the GameService class. If called again
	//it will return the same instance
	public static GameService getInstance() {
		return instance;
	}

	/**
	 * Construct a new game instance
	 * 
	 * @param name the unique name of the game
	 * @return the game instance (new or existing)
	 */
	public Game addGame(String name) {

		// a local game instance
		Game game = null;

		//update: Implemented proper iterator
		//this loop looks through each game contained in the games list
		//and checks its name string. If the game name string is 
		//equal to the name string passed as a parameter then the variable game
		//is set equal to the game instance and returned.
		//if the game name is not found then the method creates a new game with 
		//the requested name
		    for(Game element : games) { 
		    	if (element.name.equals(name)) {
				game = element;
				break;
		    	}
		    }
			

		// if not found, make a new game instance and add to list of games
		
		if (game == null) {
			
			game = new Game(nextGameId++, name);
			games.add(game);
		}
		
		// return the new/existing game instance to the caller
		return game;
	}

	/**
	 * Returns the game instance at the specified index.
	 * <p>
	 * Scope is package/local for testing purposes.
	 * </p>
	 * @param index index position in the list to return
	 * @return requested game instance
	 */
	Game getGame(int index) {
		return games.get(index);
	}
	
	/**
	 * Returns the game instance with the specified id.
	 * 
	 * @param id unique identifier of game to search for
	 * @return requested game instance
	 */
	public Game getGame(long id) {

		// a local game instance
		Game game = null;

		//update: Implemented proper iterator
		//itterate through all the games in the games list and check their
		//id against the id passed as a parameter. If the id is found
		//break the loop and return the game instance
		for(Game element : games) {
			if (element.id == id) {
				game = element;
				break;
			}
			
        }
		return game;
	}

	/**
	 * Returns the game instance with the specified name.
	 * 
	 * @param name unique name of game to search for
	 * @return requested game instance
	 */
	public Game getGame(String name) {

		// a local game instance
		Game game = null;

		//update: Implemented proper iterator
		//itterate through each game in the games list and compare the name
		//to the one passed as a parameter. If the game name matches the parameter
		//return the game instance
		for(Game element : games) {
			if (element.name == name) {
				game = element;
				break;
			}
		}
		return game;
	}
	
	/**
	 * Returns the number of games currently active
	 * 
	 * @return the number of games currently active
	 */
	public int getGameCount() {
		return games.size();
	}
	
	//returns the next player id and incriments the value by 1
	public long getNextPlayerId() {
		return nextPlayerId++;
	}
	
	//returns the next team id and incriments the value by 1
	public long getNextTeamId() {
		return nextTeamId++;
	}
	
}
