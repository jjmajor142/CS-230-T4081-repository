/*Joshua Major
 * CS-230-T4081
 * 02/20/2021
 * Project1
 */
package com.gamingroom;
import java.util.ArrayList;

/**
 * A simple class to hold information about a game
 * 
 * <p>
 * Notice the overloaded constructor that requires
 * an id and name to be passed when creating.
 * Also note that no mutators (setters) defined so
 * these values cannot be changed once a game is
 * created.
 * </p>
 * 
 * @author coce@snhu.edu
 *
 */
public class Game extends Entity{
	long id;
	String name;
	//An array to hold all the Team instances
	ArrayList<Team> teams = new ArrayList<Team>();
	
	/**
	 * Hide the default constructor to prevent creating empty instances.
	 */
	private Game() {
	}

	/**
	 * Constructor with an identifier and name
	 */
	public Game(long id, String name) {
		this();
		this.id = id;
		this.name = name;
	}


	//A method to add a new game. If the game name already exists the method returns that game
	public Team addTeam(String name) {
		Team team = null;
		
		//Loop through the list of existing teams to check if the name
		//already is taken
		for (int i = 0; i < teams.size(); i++) {
			if (teams.get(i).name == name) {
				team = teams.get(i);
				break;
			}
			
        }
		
		//if the name is not taken create a new Team instance
		if (team == null) {
			
			team = new Team(GameService.getInstance().getNextTeamId(), name);
					teams.add(team);
				}
		return team;
	}
	
	//override to default to the Entity class
	@Override
	public String toString() {
		return "Game [id=" + id + ", name=" + name + "]";
	}

}
