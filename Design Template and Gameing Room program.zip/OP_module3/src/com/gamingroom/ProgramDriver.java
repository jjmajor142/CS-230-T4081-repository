/*Joshua Major
 * CS-230-T4081
 * 02/20/2021
 * Project1
 */

package com.gamingroom;

/**
 * Application start-up program
 * 
 * @author coce@snhu.edu
 */
public class ProgramDriver {
	
	/**
	 * The one-and-only main() method
	 * 
	 * @param args command line arguments
	 */
	public static void main(String[] args) {
		
		//GameService.getInstance() returns a singleton instance of the 
		//GameService class. If the getInstance() method is called again
		//it will return the same instance rather than a new one
		GameService service = GameService.getInstance(); 
		
		//Create a new game and add it to the to the game list
		Game game = service.addGame("My first game");

		//create a new team
		Team team = game.addTeam("Team 1");
		
		team.addPlayer("Player 1");
		//Try to add a player of the same name
		team.addPlayer("Player 1");
		System.out.println("Team size: " +team.players.size());
		System.out.println("Size should be 1 because you can't add a duplicate name.\n");
		
		//Add a players with a new names
		team.addPlayer("Player 2");
		team.addPlayer("Player 3");
		System.out.println(game.toString());
		System.out.println(game.teams.get(0).toString());
		for (int i = 0; i < team.players.size(); i++) {
		System.out.println(team.players.get(i).toString());
		}
		System.out.println();
		
		//add a second team with new players
		Team team2 = game.addTeam("Team 2");
		team2.addPlayer("Player 4");
		team2.addPlayer("Player 5");
		team2.addPlayer("Player 6");
		System.out.println(game.toString());
		System.out.println(game.teams.get(1).toString());
		for (int i = 0; i < team2.players.size(); i++) {
		System.out.println(team2.players.get(i).toString());
		}
		System.out.println("\n\n");
		
		//add a second game with new players and print all the information
		Game game2 = service.addGame("My second game");
		Team team3 = game2.addTeam("Team 1");
		team3.addPlayer("Player 7");
		team3.addPlayer("Player 8");
		team3.addPlayer("Player 9");
		System.out.println(game2.toString());
		System.out.println(game2.teams.get(0).toString());
		for (int i = 0; i < team3.players.size(); i++) {
		System.out.println(team3.players.get(i).toString());
		}
		
		System.out.println();
		Team team4 = game2.addTeam("Team 2");
		team4.addPlayer("Player 10");
		team4.addPlayer("Player 11");
		team4.addPlayer("Player 12");
		System.out.println(game2.toString());
		System.out.println(game2.teams.get(1).toString());
		for (int i = 0; i < team4.players.size(); i++) {
		System.out.println(team4.players.get(i).toString());
		}
		
		
		
		//print out the list of games
		System.out.println("\n\nPrint the list of current games");
		for (int i = 0; i < service.getGameCount(); i++) {
			System.out.println(service.getGame(i));
		}
		
		
		// use another class to prove there is only one instance
		SingletonTester tester = new SingletonTester();
		tester.testSingleton();
		
	}
}
