/*Joshua Major
 * CS-230-T4081
 * 02/20/2021
 * Project1
 */
package com.gamingroom;
import java.util.ArrayList;

/**
 * A simple class to hold information about a team
 * <p>
 * Notice the overloaded constructor that requires
 * an id and name to be passed when creating.
 * Also note that no mutators (setters) defined so
 * these values cannot be changed once a team is
 * created.
 * </p>
 * @author coce@snhu.edu
 *
 */
public class Team extends Entity{
	ArrayList<Player> players = new ArrayList<Player>();
	
	/*
	 * Constructor with an identifier and name
	 */
	public Team(long id, String name) {
		this.id = id;
		this.name = name;
		
	}
	
	//A method to add a new player and check if the player name is already taken
	public void addPlayer(String name) {
		Player player = null;

		//loop through the exsisting player names. If the name is taken return that player instance
		for (int i = 0; i < players.size(); i++) {
			if (players.get(i).name == name) {
				player = players.get(i);
				break;
			}
			
        }
		
		//if the name is not taken then create a new player instance
		if (player == null) {
			player = new Player(GameService.getInstance().getNextPlayerId(), name);
					players.add(player);
				}
	}

	//override to defer to the Entity class
	@Override
	public String toString() {
		return "Team [id=" + id + ", name=" + name + "]";
	}
}
