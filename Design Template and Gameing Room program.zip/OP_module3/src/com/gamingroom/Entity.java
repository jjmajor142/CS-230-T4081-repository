/*Joshua Major
 * CS-230-T4081
 * 02/20/2021
 * Project1
 */
package com.gamingroom;

//The entity class holds common attributes and methods for each of it's child classes
public class Entity {
	long id;
	String name;
	
	//Hide the default constructor to prevent creating empty instances.
	protected Entity() {
	}

	//Take in the id and name of the entity as parameters
	public Entity(long id, String name) {
		this();
		this.id = id;
		this.name = name;
	}
	/**
	 * @return the id
	 */
	public long getId() {
		return id;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	//prints all important information about the entity instance
	public String toString() {
		
		return "Entity [id=" + id + ", name=" + name + "]";
	}

}

